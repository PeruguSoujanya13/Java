package Arrays;

public class Main {
	public static void main(String[] args) {
		Rotate r = new Rotate();
        		int arr[] = { 7, 21, 23, 27, 19, 13, 17 }; 
        		r.rotate(arr, 5); 
        		for(int i=0;i<arr.length;i++){
            			System.out.print(arr[i]+" ");
        		}
	}
}

