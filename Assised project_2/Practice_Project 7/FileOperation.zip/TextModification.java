package Mechanisms;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class TextModification {


    public static void main(String[] args) {
        
        try {
            File file = new File("example.txt");
            FileWriter writer = new FileWriter(file, true);
            writer.write("This is some new content.\n");
            writer.close();
            System.out.println("File updated successfully!");
        } catch (IOException e) {
            System.out.println("An error occurred: " + e);
        }
    }
}