package Project;

public class Mythreads {
	
	public void start()
 	{
  		System.out.println("the  threaing was started running..");
}
 	public static void main( String args[] )
 	{
  		Mythreads mt = new  Mythreads();
  		mt.start();
 	}
}

