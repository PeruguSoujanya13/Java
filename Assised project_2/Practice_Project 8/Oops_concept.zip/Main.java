package Oops_concept;

//class1
class Animal {
 public void eat() {
     System.out.println("The animal is eating.");
 }

 public void sleep() {
     System.out.println("The animal is sleeping.");
 }
}

//class 2
class Dog extends Animal {
 public void bark() {
     System.out.println("The dog is barking.");
 }
}

public class Main {
	
	  public static void main(String[] args) {
	        // create a new Dog object
	        Dog dog1 = new Dog();

	        // call the methods from the Animal class
	        dog1.eat();
	        dog1.sleep();

	        // call the method specific to the Dog class
	        dog1.bark();
	    }


}
