package Javaprogram;

public class Throws {
	
	public static void main(String[] args) {
		// Throws Demo
		
		Class1 c1 = new Class1();
		
		try {
			
		c1.division();
		
		}catch(Exception e) {
			System.out.print("\nExceptoion happend : " + e);	
		}

	}

}

//
class Class1 {

	void division() throws Exception {
		int a = 45, b = 0, rs;
		rs = a / b;
		System.out.print("\n\tThe result is : " + rs);
	}
}
class Class2 {
	
	// Author of class1 is saying that he wont 
	// handle the exception for the statements
	// in this method.
	// Author wants the caller to handle the exception
	// when he/she invokes this method
	void division() throws Exception {
		int a = 45, b = 0, rs;
		rs = a / b;
		System.out.print("\n\tThe result is : " + rs);
	}
}

