package Javaprogram;

public class Finally {

public static void main(String[] args) {
	
	try {

	} catch (ArithmeticException Ex) {
		System.out.println("Exception happened : " + Ex.getMessage());
	} catch (NullPointerException e) {
		System.out.println("Exception happened : " + e.getMessage());
	} catch (Exception e) {
		System.out.println("Exception happened : " + e.getMessage());
	}
	finally {
		System.out.println("In finally block");
	}

	///
	System.out.println("End of Program");

}

}
